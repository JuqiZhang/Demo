package com.ynuedu.partbuilding.Repositories;

import com.ynuedu.partbuilding.Entities.Mission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.SplittableRandom;

public interface MissionRepository
        extends JpaRepository<Mission,String>
{
}
