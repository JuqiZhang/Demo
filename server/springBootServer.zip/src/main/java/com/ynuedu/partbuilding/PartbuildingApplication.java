package com.ynuedu.partbuilding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartbuildingApplication {

    public static void main(String[] args) {
        SpringApplication.run(PartbuildingApplication.class, args);
    }
}
