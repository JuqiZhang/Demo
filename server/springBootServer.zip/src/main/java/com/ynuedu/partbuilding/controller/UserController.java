package com.ynuedu.partbuilding.controller;

import com.ynuedu.partbuilding.Entities.Mission;
import com.ynuedu.partbuilding.Entities.UserInfo;
import com.ynuedu.partbuilding.Repositories.MissionRepository;
import com.ynuedu.partbuilding.Repositories.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * 用户控制器
 */
@RestController
public class UserController {

    //引入数据访问器，自动注入
    @Autowired
    MissionRepository missionDao;

    @Autowired
    UserInfoRepository usDao;

    @GetMapping(value = "/mission")
    public List<Mission> getMission() {

        List<Mission> ms = missionDao.findAll();
        List<UserInfo> uss =usDao.findAll();

        Mission m1 = new Mission();
        m1.title="上课测试";
        m1.level="天灾";
        missionDao.save(m1);

        return ms;
    }

    @GetMapping(value = "/addTestUser")
    public List<UserInfo> getUser() {

        List<UserInfo> users = new ArrayList<UserInfo>();
        for (int i = 0; i < 10; i++) {
            UserInfo s1 = new UserInfo();
            s1.name = "学生" + i;
            s1.userName="user"+i;
            s1.password="123";
            users.add(s1);
        }

        usDao.saveAll(users);
        return users;
    }


}
